#!/usr/bin/env python3
"""
Sistema de Membresía RelaticPanama
Backend Flask para gestión de usuarios y membresías
"""

import sys
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import os
import secrets
import stripe
from flask_mail import Mail, Message
try:
    from email_service import EmailService
    from email_templates import (
        get_membership_payment_confirmation_email,
        get_membership_expiring_email,
        get_membership_expired_email,
        get_membership_renewed_email,
        get_event_registration_email,
        get_event_cancellation_email,
        get_event_update_email,
        get_appointment_confirmation_email,
        get_appointment_reminder_email,
        get_welcome_email,
        get_password_reset_email
    )
    EMAIL_TEMPLATES_AVAILABLE = True
except ImportError:
    EMAIL_TEMPLATES_AVAILABLE = False
    print("⚠️ Email templates no disponibles. Usando templates básicos.")

# Configuración de la aplicación
app = Flask(__name__, template_folder='../templates', static_folder='../static')

# Ensure module alias 'app' points to this instance even when running as __main__
sys.modules.setdefault('app', sys.modules[__name__])
app.config['SECRET_KEY'] = secrets.token_hex(16)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///relaticpanama.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Configuración de Stripe
stripe.api_key = os.getenv('STRIPE_SECRET_KEY', 'sk_test_your_stripe_secret_key_here')
STRIPE_PUBLISHABLE_KEY = os.getenv('STRIPE_PUBLISHABLE_KEY', 'pk_test_your_stripe_publishable_key_here')

# Configuración de Mail
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME', 'your_email@gmail.com')
app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD', 'your_app_password')
app.config['MAIL_DEFAULT_SENDER'] = os.getenv('MAIL_DEFAULT_SENDER', 'noreply@relaticpanama.org')

# Inicialización de extensiones
db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
mail = Mail(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Por favor, inicia sesión para acceder a esta página.'

# Inicializar servicio de correo
if EMAIL_TEMPLATES_AVAILABLE:
    email_service = EmailService(mail)
else:
    email_service = None

# Modelos de la base de datos
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    phone = db.Column(db.String(20))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    is_admin = db.Column(db.Boolean, default=False)  # Campo para administradores
    is_advisor = db.Column(db.Boolean, default=False)  # Campo para asesores que atienden citas
    
    # Relación con membresías
    memberships = db.relationship('Membership', backref='user', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_active_membership(self):
        # Buscar suscripción activa primero
        active_subscription = Subscription.query.filter_by(
            user_id=self.id, 
            status='active'
        ).filter(Subscription.end_date > datetime.utcnow()).first()
        
        if active_subscription:
            return active_subscription
        
        # Fallback al sistema anterior si existe
        return Membership.query.filter_by(user_id=self.id, is_active=True).first()

class Membership(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    membership_type = db.Column(db.String(50), nullable=False)  # 'basic', 'pro', 'premium', 'deluxe'
    start_date = db.Column(db.DateTime, default=datetime.utcnow)
    end_date = db.Column(db.DateTime, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    payment_status = db.Column(db.String(20), default='pending')  # 'pending', 'paid', 'failed'
    amount = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def is_currently_active(self):
        """Verificar si la membresía está actualmente activa"""
        return self.is_active and datetime.utcnow() <= self.end_date

class Benefit(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    membership_type = db.Column(db.String(50), nullable=False)
    is_active = db.Column(db.Boolean, default=True)

class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    stripe_payment_intent_id = db.Column(db.String(100), unique=True, nullable=False)
    amount = db.Column(db.Integer, nullable=False)  # Amount in cents
    currency = db.Column(db.String(3), default='usd')
    status = db.Column(db.String(20), default='pending')  # pending, succeeded, failed
    membership_type = db.Column(db.String(50), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = db.relationship('User', backref=db.backref('payments', lazy=True))

class Subscription(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    payment_id = db.Column(db.Integer, db.ForeignKey('payment.id'), nullable=False)
    membership_type = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), default='active')  # active, expired, cancelled
    start_date = db.Column(db.DateTime, default=datetime.utcnow)
    end_date = db.Column(db.DateTime, nullable=False)
    auto_renew = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = db.relationship('User', backref=db.backref('subscriptions', lazy=True))
    payment = db.relationship('Payment', backref=db.backref('subscription', uselist=False))
    
    def is_currently_active(self):
        """Verificar si la suscripción está actualmente activa"""
        return self.status == 'active' and datetime.utcnow() <= self.end_date
    
    @property
    def is_active(self):
        """Propiedad para compatibilidad con Membership"""
        return self.is_currently_active()

# Modelos de Eventos
class Event(db.Model):
    """Modelo para eventos según el diagrama de flujo - 5 pasos: Evento, Descripción, Publicidad, Certificado, Kahoot"""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    slug = db.Column(db.String(200), unique=True, nullable=False)
    summary = db.Column(db.Text)
    description = db.Column(db.Text)
    category = db.Column(db.String(50), default='general')
    format = db.Column(db.String(50), default='virtual')  # virtual, presencial, híbrido
    tags = db.Column(db.String(500))
    base_price = db.Column(db.Float, default=0.0)
    currency = db.Column(db.String(3), default='USD')
    registration_url = db.Column(db.String(500))
    contact_email = db.Column(db.String(120))
    contact_phone = db.Column(db.String(20))
    location = db.Column(db.String(200))
    country = db.Column(db.String(100))
    # Campos adicionales según diagrama
    venue = db.Column(db.String(200))  # Sede o Universidad
    university = db.Column(db.String(200))  # Universidad organizadora
    is_virtual = db.Column(db.Boolean, default=False)
    has_certificate = db.Column(db.Boolean, default=False)
    certificate_instructions = db.Column(db.Text)
    certificate_template = db.Column(db.String(500))  # Template del certificado
    # Integración Kahoot
    kahoot_enabled = db.Column(db.Boolean, default=False)
    kahoot_link = db.Column(db.String(500))
    kahoot_required = db.Column(db.Boolean, default=False)  # Si es obligatorio participar
    # Flujo de 5 pasos
    step_1_event_completed = db.Column(db.Boolean, default=False)  # 1. Evento
    step_2_description_completed = db.Column(db.Boolean, default=False)  # 2. Descripción
    step_3_publicity_completed = db.Column(db.Boolean, default=False)  # 3. Publicidad
    step_4_certificate_completed = db.Column(db.Boolean, default=False)  # 4. Certificado
    step_5_kahoot_completed = db.Column(db.Boolean, default=False)  # 5. Kahoot
    # Salidas del evento (Carteles, Revistas, Libros)
    generates_poster = db.Column(db.Boolean, default=False)
    generates_magazine = db.Column(db.Boolean, default=False)
    generates_book = db.Column(db.Boolean, default=False)
    # Capacidad y registro
    capacity = db.Column(db.Integer, default=0)
    registered_count = db.Column(db.Integer, default=0)
    visibility = db.Column(db.String(20), default='members')  # members, public
    publish_status = db.Column(db.String(20), default='draft')  # draft, published, archived
    featured = db.Column(db.Boolean, default=False)
    start_date = db.Column(db.DateTime, nullable=False)
    end_date = db.Column(db.DateTime, nullable=False)
    registration_deadline = db.Column(db.DateTime)
    cover_image = db.Column(db.String(500))
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    # Roles del evento: Moderador, Administrador, Expositor
    moderator_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)  # Moderador del evento
    administrator_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)  # Administrador del evento
    speaker_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)  # Expositor/Conferencista principal
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relaciones
    images = db.relationship('EventImage', backref='event', lazy=True, cascade='all, delete-orphan')
    discounts = db.relationship('EventDiscount', backref='event', lazy=True, cascade='all, delete-orphan')
    creator = db.relationship('User', foreign_keys=[created_by], backref='created_events')
    moderator = db.relationship('User', foreign_keys=[moderator_id], backref='moderated_events')
    administrator = db.relationship('User', foreign_keys=[administrator_id], backref='administered_events')
    speaker = db.relationship('User', foreign_keys=[speaker_id], backref='speaker_events')
    
    def get_notification_recipients(self):
        """Obtiene todos los usuarios que deben recibir notificaciones del evento"""
        recipients = []
        
        # Creador del evento
        if self.created_by:
            creator = User.query.get(self.created_by)
            if creator:
                recipients.append(creator)
        
        # Moderador
        if self.moderator_id:
            moderator = User.query.get(self.moderator_id)
            if moderator and moderator not in recipients:
                recipients.append(moderator)
        
        # Administrador del evento
        if self.administrator_id:
            administrator = User.query.get(self.administrator_id)
            if administrator and administrator not in recipients:
                recipients.append(administrator)
        
        # Expositor
        if self.speaker_id:
            speaker = User.query.get(self.speaker_id)
            if speaker and speaker not in recipients:
                recipients.append(speaker)
        
        # Si no hay roles asignados, notificar a todos los administradores del sistema
        if not recipients:
            admins = User.query.filter_by(is_admin=True).all()
            recipients.extend(admins)
        
        return recipients
    
    def cover_url(self):
        """Retorna la URL de la imagen de portada"""
        if self.cover_image:
            return self.cover_image
        return '/static/images/default-event.jpg'
    
    def pricing_for_membership(self, membership_type=None):
        """Calcula el precio final según el tipo de membresía"""
        base_price = self.base_price or 0.0
        discount = None
        final_price = base_price
        
        if membership_type:
            # Buscar descuento aplicable para este tipo de membresía
            event_discount = EventDiscount.query.join(Discount).filter(
                EventDiscount.event_id == self.id,
                Discount.membership_tier == membership_type,
                Discount.is_active == True
            ).order_by(EventDiscount.priority.asc()).first()
            
            if event_discount:
                discount = event_discount.discount
                if discount.discount_type == 'percentage':
                    final_price = base_price * (1 - discount.value / 100)
                elif discount.discount_type == 'fixed':
                    final_price = max(0, base_price - discount.value)
        
        return {
            'base_price': base_price,
            'final_price': final_price,
            'discount': discount
        }

class EventImage(db.Model):
    """Imágenes de galería para eventos"""
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    file_path = db.Column(db.String(500), nullable=False)
    sort_order = db.Column(db.Integer, default=0)
    is_primary = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Discount(db.Model):
    """Descuentos reutilizables - Sistema de descuentos por categorías según diagrama:
    Básico (Ba), Pro 10%, R 20%, DX 30%"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    code = db.Column(db.String(50), unique=True)
    description = db.Column(db.Text)
    discount_type = db.Column(db.String(20), default='percentage')  # percentage, fixed
    value = db.Column(db.Float, nullable=False)
    membership_tier = db.Column(db.String(50))  # basic, pro, premium, deluxe, r, dx
    category = db.Column(db.String(50), default='event')  # event, appointment, service
    applies_automatically = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    max_uses = db.Column(db.Integer)
    uses = db.Column(db.Integer, default=0)  # Alias para compatibilidad con esquema antiguo
    current_uses = db.Column(db.Integer, default=0)  # Contador de usos
    start_date = db.Column(db.DateTime)
    end_date = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relación con eventos y citas
    events = db.relationship('EventDiscount', backref='discount', lazy=True)
    
    def can_use(self):
        """Verifica si el descuento puede ser usado"""
        if not self.is_active:
            return False
        # Usar current_uses como fuente de verdad, con fallback a uses
        uses_count = self.current_uses if hasattr(self, 'current_uses') and self.current_uses is not None else (self.uses if hasattr(self, 'uses') and self.uses is not None else 0)
        if self.max_uses and uses_count >= self.max_uses:
            return False
        now = datetime.utcnow()
        if self.start_date and now < self.start_date:
            return False
        if self.end_date and now > self.end_date:
            return False
        return True

class EventDiscount(db.Model):
    """Relación muchos a muchos entre eventos y descuentos"""
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    discount_id = db.Column(db.Integer, db.ForeignKey('discount.id'), nullable=False)
    priority = db.Column(db.Integer, default=1)  # Orden de aplicación si hay múltiples
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


# ---------------------------------------------------------------------------
# Modelos adicionales para eventos según el diagrama de flujo
# ---------------------------------------------------------------------------
class EventParticipant(db.Model):
    """Participantes de eventos con categorías (participantes, asistentes, ponentes)"""
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    participation_category = db.Column(db.String(50), nullable=False)  # participant, attendee, speaker
    registration_date = db.Column(db.DateTime, default=datetime.utcnow)
    check_in_time = db.Column(db.DateTime)  # Hora de llegada/check-in
    check_out_time = db.Column(db.DateTime)  # Hora de salida/check-out
    attendance_confirmed = db.Column(db.Boolean, default=False)
    payment_status = db.Column(db.String(20), default='pending')  # pending, paid, refunded
    payment_amount = db.Column(db.Float, default=0.0)
    discount_applied = db.Column(db.Float, default=0.0)
    membership_type_at_registration = db.Column(db.String(50))  # Para aplicar descuentos históricos
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    event = db.relationship('Event', backref='participants')
    user = db.relationship('User', backref='event_participations')
    
    __table_args__ = (
        db.UniqueConstraint('event_id', 'user_id', name='uq_event_user'),
    )


class EventSpeaker(db.Model):
    """Ponentes/Exponentes de eventos"""
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)  # Puede ser externo
    name = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(120))
    bio = db.Column(db.Text)
    photo_url = db.Column(db.String(500))
    organization = db.Column(db.String(200))  # Sede o Universidad
    country = db.Column(db.String(100))
    title = db.Column(db.String(200))  # Título de la presentación
    topic_description = db.Column(db.Text)  # Información del tema
    presentation_time = db.Column(db.DateTime)  # Hora de la presentación
    duration_minutes = db.Column(db.Integer, default=30)
    sort_order = db.Column(db.Integer, default=0)
    is_confirmed = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    event = db.relationship('Event', backref='speakers')
    user = db.relationship('User', backref='speaker_appearances')


class EventCertificate(db.Model):
    """Certificados generados para participantes de eventos"""
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    participant_id = db.Column(db.Integer, db.ForeignKey('event_participant.id'), nullable=False)
    certificate_number = db.Column(db.String(100), unique=True, nullable=False)
    certificate_url = db.Column(db.String(500))  # URL del PDF generado
    preview_url = db.Column(db.String(500))  # URL del preview
    issued_date = db.Column(db.DateTime, default=datetime.utcnow)
    issued_by = db.Column(db.Integer, db.ForeignKey('user.id'))  # Admin que emitió
    email_sent = db.Column(db.Boolean, default=False)
    email_sent_at = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    event = db.relationship('Event', backref='certificates')
    participant = db.relationship('EventParticipant', backref='certificates')
    issuer = db.relationship('User', backref='certificates_issued')


class EventWorkshop(db.Model):
    """Talleres dentro de eventos"""
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    instructor_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    instructor_name = db.Column(db.String(200))  # Si es externo
    start_datetime = db.Column(db.DateTime, nullable=False)
    end_datetime = db.Column(db.DateTime, nullable=False)
    location = db.Column(db.String(200))  # Sala, link virtual, etc.
    capacity = db.Column(db.Integer, default=0)
    registered_count = db.Column(db.Integer, default=0)
    price = db.Column(db.Float, default=0.0)
    is_included = db.Column(db.Boolean, default=True)  # Si está incluido en el evento
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    event = db.relationship('Event', backref='workshops')
    instructor = db.relationship('User', backref='workshops_taught')


class EventTopic(db.Model):
    """Temas/Presentaciones de eventos"""
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    speaker_id = db.Column(db.Integer, db.ForeignKey('event_speaker.id'), nullable=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    topic_type = db.Column(db.String(50))  # presentation, panel, keynote, etc.
    start_time = db.Column(db.DateTime)
    duration_minutes = db.Column(db.Integer, default=30)
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    event = db.relationship('Event', backref='topics')
    speaker = db.relationship('EventSpeaker', backref='topics')


class Notification(db.Model):
    """Sistema de notificaciones para eventos y movimientos del sistema"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=True)  # NULL si no es relacionado a evento
    notification_type = db.Column(db.String(50), nullable=False)  # event_registration, event_cancellation, event_confirmation, event_update, etc.
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    email_sent = db.Column(db.Boolean, default=False)
    email_sent_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relaciones
    user = db.relationship('User', backref='notifications')
    event = db.relationship('Event', backref='notifications')
    
    def mark_as_read(self):
        """Marcar notificación como leída"""
        self.is_read = True
        db.session.commit()


class EmailLog(db.Model):
    """Registro completo de todos los emails enviados por el sistema"""
    id = db.Column(db.Integer, primary_key=True)
    recipient_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)  # NULL si es email externo
    recipient_email = db.Column(db.String(120), nullable=False)  # Email del destinatario
    recipient_name = db.Column(db.String(200))  # Nombre del destinatario
    subject = db.Column(db.String(500), nullable=False)
    html_content = db.Column(db.Text)  # Contenido HTML del email
    text_content = db.Column(db.Text)  # Contenido de texto plano
    email_type = db.Column(db.String(50), nullable=False)  # membership_payment, event_registration, appointment_confirmation, etc.
    related_entity_type = db.Column(db.String(50))  # membership, event, appointment, payment, etc.
    related_entity_id = db.Column(db.Integer)  # ID de la entidad relacionada
    status = db.Column(db.String(20), default='sent')  # sent, failed, pending
    error_message = db.Column(db.Text)  # Mensaje de error si falló
    retry_count = db.Column(db.Integer, default=0)
    sent_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relaciones
    recipient = db.relationship('User', backref='email_logs', foreign_keys=[recipient_id])
    
    def to_dict(self):
        """Convertir a diccionario para JSON"""
        return {
            'id': self.id,
            'recipient_email': self.recipient_email,
            'recipient_name': self.recipient_name,
            'subject': self.subject,
            'email_type': self.email_type,
            'related_entity_type': self.related_entity_type,
            'related_entity_id': self.related_entity_id,
            'status': self.status,
            'retry_count': self.retry_count,
            'sent_at': self.sent_at.isoformat() if self.sent_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class EventRegistration(db.Model):
    """Registro completo de eventos con flujo de email y almacenamiento"""
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    registration_date = db.Column(db.DateTime, default=datetime.utcnow)
    registration_status = db.Column(db.String(20), default='pending')  # pending, confirmed, cancelled, completed
    # Flujo de emails
    confirmation_email_sent = db.Column(db.Boolean, default=False)
    confirmation_email_sent_at = db.Column(db.DateTime)
    reminder_email_sent = db.Column(db.Boolean, default=False)
    reminder_email_sent_at = db.Column(db.DateTime)
    certificate_email_sent = db.Column(db.Boolean, default=False)
    certificate_email_sent_at = db.Column(db.DateTime)
    # Integración Kahoot
    kahoot_link = db.Column(db.String(500))
    kahoot_participated = db.Column(db.Boolean, default=False)
    kahoot_score = db.Column(db.Integer)
    # Descuentos aplicados
    base_price = db.Column(db.Float, default=0.0)
    discount_applied = db.Column(db.Float, default=0.0)
    final_price = db.Column(db.Float, default=0.0)
    membership_type = db.Column(db.String(50))
    discount_code_used = db.Column(db.String(50))
    # Pagos
    payment_status = db.Column(db.String(20), default='pending')
    payment_method = db.Column(db.String(50))
    payment_reference = db.Column(db.String(100))
    payment_date = db.Column(db.DateTime)
    # Datos adicionales
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    event = db.relationship('Event', backref='registrations')
    user = db.relationship('User', backref='event_registrations')
    
    __table_args__ = (
        db.UniqueConstraint('event_id', 'user_id', name='uq_event_registration'),
    )


# ---------------------------------------------------------------------------
# Modelos de Citas / Appointments
# ---------------------------------------------------------------------------
class Advisor(db.Model):
    """Perfil de asesores internos que atienden citas."""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, unique=True)
    headline = db.Column(db.String(120))
    bio = db.Column(db.Text)
    specializations = db.Column(db.Text)
    meeting_url = db.Column(db.String(255))
    photo_url = db.Column(db.String(255))
    average_response_time = db.Column(db.String(50))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship('User', backref=db.backref('advisor_profile', uselist=False))
    advisor_assignments = db.relationship('AppointmentAdvisor', backref='advisor', lazy=True, cascade='all, delete-orphan')
    availability = db.relationship('AdvisorAvailability', backref='advisor', lazy=True, cascade='all, delete-orphan')
    slots = db.relationship('AppointmentSlot', backref='advisor', lazy=True, cascade='all, delete-orphan')
    appointments = db.relationship('Appointment', backref='advisor_profile', lazy=True)


class AppointmentType(db.Model):
    """Servicios configurables que pueden reservar los miembros."""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    service_category = db.Column(db.String(100))
    duration_minutes = db.Column(db.Integer, default=60)
    is_group_allowed = db.Column(db.Boolean, default=False)
    max_participants = db.Column(db.Integer, default=1)
    base_price = db.Column(db.Float, default=0.0)
    currency = db.Column(db.String(3), default='USD')
    is_virtual = db.Column(db.Boolean, default=True)
    requires_confirmation = db.Column(db.Boolean, default=True)
    color_tag = db.Column(db.String(20), default='#0d6efd')
    icon = db.Column(db.String(50), default='fa-calendar-check')
    display_order = db.Column(db.Integer, default=1)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    advisor_assignments = db.relationship('AppointmentAdvisor', backref='appointment_type', lazy=True, cascade='all, delete-orphan')
    pricing_rules = db.relationship('AppointmentPricing', backref='appointment_type', lazy=True, cascade='all, delete-orphan')
    slots = db.relationship('AppointmentSlot', backref='appointment_type', lazy=True, cascade='all, delete-orphan')
    appointments = db.relationship('Appointment', backref='appointment_type', lazy=True)

    def duration(self):
        return timedelta(minutes=self.duration_minutes or 60)

    def pricing_for_membership(self, membership_type=None):
        """Calcula el precio final considerando reglas por membresía."""
        base_price = self.base_price or 0.0
        final_price = base_price
        discount_percentage = 0.0
        is_included = False
        rule = None

        if membership_type:
            rule = AppointmentPricing.query.filter_by(
                appointment_type_id=self.id,
                membership_type=membership_type,
                is_active=True
            ).first()

        if rule:
            if rule.is_included:
                final_price = 0.0
                is_included = True
            elif rule.price is not None:
                final_price = rule.price
            elif rule.discount_percentage:
                discount_percentage = rule.discount_percentage
                final_price = max(0.0, base_price * (1 - discount_percentage / 100))

        return {
            'base_price': base_price,
            'final_price': final_price,
            'discount_percentage': discount_percentage,
            'is_included': is_included,
            'rule': rule
        }


class AppointmentAdvisor(db.Model):
    """Asignación de asesores a tipos de cita."""
    id = db.Column(db.Integer, primary_key=True)
    appointment_type_id = db.Column(db.Integer, db.ForeignKey('appointment_type.id'), nullable=False)
    advisor_id = db.Column(db.Integer, db.ForeignKey('advisor.id'), nullable=False)
    priority = db.Column(db.Integer, default=1)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint('appointment_type_id', 'advisor_id', name='uq_type_advisor'),
    )


class AdvisorAvailability(db.Model):
    """Bloques semanales de disponibilidad declarados por cada asesor."""
    id = db.Column(db.Integer, primary_key=True)
    advisor_id = db.Column(db.Integer, db.ForeignKey('advisor.id'), nullable=False)
    day_of_week = db.Column(db.Integer, nullable=False)  # 0 = lunes ... 6 = domingo
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    timezone = db.Column(db.String(50), default='America/Panama')
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        db.CheckConstraint('end_time > start_time', name='ck_availability_time_window'),
    )


class AppointmentPricing(db.Model):
    """Reglas de precio/descuento por tipo de membresía."""
    id = db.Column(db.Integer, primary_key=True)
    appointment_type_id = db.Column(db.Integer, db.ForeignKey('appointment_type.id'), nullable=False)
    membership_type = db.Column(db.String(50), nullable=False)
    price = db.Column(db.Float)
    discount_percentage = db.Column(db.Float, default=0.0)
    is_included = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint('appointment_type_id', 'membership_type', name='uq_pricing_membership'),
    )


class AppointmentSlot(db.Model):
    """Slots concretos de tiempo que pueden reservar los miembros."""
    id = db.Column(db.Integer, primary_key=True)
    appointment_type_id = db.Column(db.Integer, db.ForeignKey('appointment_type.id'), nullable=False)
    advisor_id = db.Column(db.Integer, db.ForeignKey('advisor.id'), nullable=False)
    start_datetime = db.Column(db.DateTime, nullable=False)
    end_datetime = db.Column(db.DateTime, nullable=False)
    capacity = db.Column(db.Integer, default=1)
    reserved_seats = db.Column(db.Integer, default=0)
    is_available = db.Column(db.Boolean, default=True)
    is_auto_generated = db.Column(db.Boolean, default=True)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    created_by_user = db.relationship('User', backref='appointment_slots_created', foreign_keys=[created_by])
    appointment = db.relationship('Appointment', backref='slot', uselist=False)

    __table_args__ = (
        db.CheckConstraint('capacity >= 1', name='ck_slot_capacity_positive'),
        db.CheckConstraint('end_datetime > start_datetime', name='ck_slot_time_window'),
    )

    def remaining_seats(self):
        return max(0, (self.capacity or 1) - (self.reserved_seats or 0))


class Appointment(db.Model):
    """Reservas realizadas por miembros - Modelo inspirado en Odoo."""
    id = db.Column(db.Integer, primary_key=True)
    reference = db.Column(db.String(40), unique=True, default=lambda: secrets.token_hex(4).upper())
    appointment_type_id = db.Column(db.Integer, db.ForeignKey('appointment_type.id'), nullable=False)
    advisor_id = db.Column(db.Integer, db.ForeignKey('advisor.id'), nullable=False)
    slot_id = db.Column(db.Integer, db.ForeignKey('appointment_slot.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    membership_type = db.Column(db.String(50))
    is_group = db.Column(db.Boolean, default=False)
    start_datetime = db.Column(db.DateTime, nullable=False)
    end_datetime = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, confirmed, cancelled, completed, no_show
    advisor_confirmed = db.Column(db.Boolean, default=False)
    advisor_confirmed_at = db.Column(db.DateTime)
    cancellation_reason = db.Column(db.Text)
    cancelled_by = db.Column(db.String(20))  # user, advisor, system
    cancelled_at = db.Column(db.DateTime)
    base_price = db.Column(db.Float, default=0.0)
    final_price = db.Column(db.Float, default=0.0)
    discount_applied = db.Column(db.Float, default=0.0)
    payment_status = db.Column(db.String(20), default='pending')  # pending, paid, refunded, partial
    payment_method = db.Column(db.String(50))  # stripe, cash, bank_transfer, free
    payment_reference = db.Column(db.String(100))
    user_notes = db.Column(db.Text)
    advisor_notes = db.Column(db.Text)
    # Campos adicionales inspirados en Odoo
    calendar_sync_url = db.Column(db.String(500))  # URL para sincronizar con Google Calendar, Outlook, etc.
    calendar_event_id = db.Column(db.String(200))  # ID del evento en el calendario externo
    reminder_sent = db.Column(db.Boolean, default=False)  # Si se envió recordatorio
    reminder_sent_at = db.Column(db.DateTime)
    confirmation_sent = db.Column(db.Boolean, default=False)  # Si se envió confirmación
    confirmation_sent_at = db.Column(db.DateTime)
    cancellation_sent = db.Column(db.Boolean, default=False)  # Si se envió notificación de cancelación
    cancellation_sent_at = db.Column(db.DateTime)
    meeting_url = db.Column(db.String(500))  # URL de la reunión (Zoom, Teams, etc.)
    meeting_password = db.Column(db.String(100))  # Contraseña de la reunión si aplica
    check_in_time = db.Column(db.DateTime)  # Hora de llegada/check-in
    check_out_time = db.Column(db.DateTime)  # Hora de salida/check-out
    duration_actual = db.Column(db.Integer)  # Duración real en minutos
    rating = db.Column(db.Integer)  # Calificación del 1 al 5
    rating_comment = db.Column(db.Text)  # Comentario de la calificación
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship('User', backref='appointments')
    participants = db.relationship('AppointmentParticipant', backref='appointment', lazy=True, cascade='all, delete-orphan')

    def can_user_cancel(self):
        """Permite cancelar si faltan al menos 12 horas."""
        return self.start_datetime - datetime.utcnow() > timedelta(hours=12)
    
    def is_past(self):
        """Verifica si la cita ya pasó."""
        return self.end_datetime < datetime.utcnow()
    
    def is_upcoming(self):
        """Verifica si la cita está próxima (dentro de las próximas 24 horas)."""
        now = datetime.utcnow()
        return self.start_datetime > now and (self.start_datetime - now) <= timedelta(hours=24)
    
    def get_duration_minutes(self):
        """Calcula la duración en minutos."""
        if self.end_datetime and self.start_datetime:
            delta = self.end_datetime - self.start_datetime
            return int(delta.total_seconds() / 60)
        return 0


class AppointmentParticipant(db.Model):
    """Participantes adicionales (para citas grupales)."""
    id = db.Column(db.Integer, primary_key=True)
    appointment_id = db.Column(db.Integer, db.ForeignKey('appointment.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    invited_by_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    joined_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', foreign_keys=[user_id], backref='appointment_participations')
    invited_by = db.relationship('User', foreign_keys=[invited_by_id], backref='appointment_invitations', lazy=True)


class ActivityLog(db.Model):
    """Log de actividades administrativas"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    action = db.Column(db.String(50), nullable=False)  # create_event, update_event, etc.
    entity_type = db.Column(db.String(50), nullable=False)  # event, discount, user, etc.
    entity_id = db.Column(db.Integer)
    description = db.Column(db.Text)
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.String(500))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref='activity_logs')
    
    @classmethod
    def log_activity(cls, user_id, action, entity_type, entity_id, description, request=None):
        """Método helper para registrar actividades"""
        log = cls(
            user_id=user_id,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            description=description,
            ip_address=request.remote_addr if request else None,
            user_agent=request.headers.get('User-Agent') if request else None
        )
        db.session.add(log)
        return log

# Función helper para validar archivos
def allowed_file(filename):
    """Verifica si el archivo tiene una extensión permitida"""
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Configuración del login manager
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Rutas principales
@app.route('/')
def index():
    """Página principal"""
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Registro de nuevos usuarios"""
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        phone = request.form.get('phone', '')
        
        # Verificar si el usuario ya existe
        if User.query.filter_by(email=email).first():
            flash('El correo electrónico ya está registrado.', 'error')
            return render_template('register.html')
        
        # Crear nuevo usuario
        user = User(
            email=email,
            first_name=first_name,
            last_name=last_name,
            phone=phone
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        # Enviar notificación de bienvenida
        try:
            NotificationEngine.notify_welcome(user)
        except Exception as e:
            print(f"Error enviando notificación de bienvenida: {e}")
        
        flash('Registro exitoso. Por favor, inicia sesión.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Inicio de sesión"""
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password) and user.is_active:
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        else:
            flash('Credenciales inválidas.', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    """Cerrar sesión"""
    logout_user()
    flash('Has cerrado sesión exitosamente.', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    """Panel de control del usuario"""
    from app import Appointment, EventRegistration, Event
    
    active_membership = current_user.get_active_membership()
    benefits = Benefit.query.filter_by(is_active=True).all()
    
    # Calcular días desde inicio y días restantes
    days_active = None
    days_remaining = None
    now = datetime.utcnow()
    
    if active_membership:
        if active_membership.start_date:
            days_active = (now - active_membership.start_date).days
        if active_membership.end_date:
            days_remaining = (active_membership.end_date - now).days
    
    # Estadísticas del usuario
    upcoming_appointments = Appointment.query.filter(
        Appointment.user_id == current_user.id,
        Appointment.start_datetime >= now,
        Appointment.status.in_(['pending', 'confirmed'])
    ).order_by(Appointment.start_datetime.asc()).limit(5).all()
    
    past_appointments_count = Appointment.query.filter(
        Appointment.user_id == current_user.id,
        Appointment.start_datetime < now
    ).count()
    
    upcoming_events = EventRegistration.query.join(Event).filter(
        EventRegistration.user_id == current_user.id,
        EventRegistration.registration_status == 'confirmed',
        Event.start_date >= now
    ).order_by(Event.start_date.asc()).limit(5).all()
    
    registered_events_count = EventRegistration.query.filter(
        EventRegistration.user_id == current_user.id,
        EventRegistration.registration_status == 'confirmed'
    ).count()
    
    # Obtener todos los eventos públicos para el calendario
    all_public_events = Event.query.filter(
        Event.publish_status == 'published',
        Event.start_date.isnot(None)
    ).order_by(Event.start_date.asc()).all()
    
    # Detectar si es un usuario nuevo (creado en las últimas 24 horas)
    is_new_user = False
    if current_user.created_at:
        hours_since_creation = (now - current_user.created_at).total_seconds() / 3600
        is_new_user = hours_since_creation < 24
    
    # Verificar si el usuario ha visto el onboarding
    onboarding_seen = session.get('onboarding_seen', False)
    show_onboarding = is_new_user and not onboarding_seen
    
    return render_template('dashboard.html', 
                         membership=active_membership, 
                         benefits=benefits,
                         days_active=days_active,
                         days_remaining=days_remaining,
                         now=now,
                         upcoming_appointments=upcoming_appointments,
                         past_appointments_count=past_appointments_count,
                         upcoming_events=upcoming_events,
                         registered_events_count=registered_events_count,
                         all_public_events=all_public_events,
                         show_onboarding=show_onboarding,
                         is_new_user=is_new_user)

@app.route('/api/onboarding/seen', methods=['POST'])
@login_required
def mark_onboarding_seen():
    """Marca el onboarding como visto"""
    session['onboarding_seen'] = True
    return jsonify({'success': True})

@app.route('/membership')
@login_required
def membership():
    """Página de membresía"""
    active_membership = current_user.get_active_membership()
    return render_template('membership.html', membership=active_membership)

@app.route('/subscription')
@login_required
def subscription_form():
    """Formulario de suscripción adicional (membresía $30)"""
    return render_template('subscription_form.html')

@app.route('/benefits')
@login_required
def benefits():
    """Página de beneficios"""
    active_membership = current_user.get_active_membership()
    if not active_membership:
        flash('Necesitas una membresía activa para acceder a los beneficios.', 'warning')
        return redirect(url_for('membership'))
    
    benefits = Benefit.query.filter_by(
        membership_type=active_membership.membership_type,
        is_active=True
    ).all()
    
    return render_template('benefits.html', benefits=benefits)

@app.route('/profile')
@login_required
def profile():
    """Perfil del usuario"""
    return render_template('profile.html')

@app.route('/services')
@login_required
def services():
    """Módulo de Servicios"""
    active_membership = current_user.get_active_membership()
    return render_template('services.html', membership=active_membership)

@app.route('/office365')
@login_required
def office365():
    """Módulo de Office 365"""
    active_membership = current_user.get_active_membership()
    return render_template('office365.html', membership=active_membership)

@app.route('/foros')
@login_required
def foros():
    """Módulo de Foros para miembros"""
    active_membership = current_user.get_active_membership()
    if not active_membership:
        flash('Necesitas una membresía activa para acceder a los Foros.', 'warning')
        return redirect(url_for('membership'))
    return render_template('foros.html', membership=active_membership)

@app.route('/grupos')
@login_required
def grupos():
    """Módulo de Grupos para miembros"""
    active_membership = current_user.get_active_membership()
    if not active_membership:
        flash('Necesitas una membresía activa para acceder a los Grupos.', 'warning')
        return redirect(url_for('membership'))
    return render_template('grupos.html', membership=active_membership)

@app.route('/settings')
@login_required
def settings():
    """Módulo de Configuración"""
    return render_template('settings.html')

@app.route('/notifications')
@login_required
def notifications():
    """Módulo de Notificaciones"""
    # Obtener notificaciones del usuario
    user_notifications = Notification.query.filter_by(
        user_id=current_user.id
    ).order_by(Notification.created_at.desc()).all()
    
    # Contar no leídas
    unread_count = Notification.query.filter_by(
        user_id=current_user.id,
        is_read=False
    ).count()
    
    return render_template('notifications.html', 
                         notifications=user_notifications,
                         unread_count=unread_count)

@app.route('/help')
@login_required
def help():
    """Módulo de Ayuda"""
    return render_template('help.html')

# Rutas de pago
@app.route('/checkout/<membership_type>')
@login_required
def checkout(membership_type):
    """Página de checkout para pagos"""
    if membership_type not in ['basic', 'pro', 'premium', 'deluxe']:
        flash('Tipo de membresía inválido.', 'error')
        return redirect(url_for('membership'))
    
    # Precios en centavos
    prices = {
        'basic': 0,         # $0.00 - Plan gratuito
        'pro': 6000,        # $60.00
        'premium': 12000,   # $120.00
        'deluxe': 20000     # $200.00
    }
    
    amount = prices[membership_type]
    
    return render_template('checkout.html', 
                         membership_type=membership_type,
                         amount=amount,
                         stripe_publishable_key=STRIPE_PUBLISHABLE_KEY)

@app.route('/create-payment-intent', methods=['POST'])
@login_required
def create_payment_intent():
    """Crear Payment Intent de Stripe (Modo Demo)"""
    try:
        data = request.get_json()
        membership_type = data['membership_type']
        amount = data['amount']
        
        # Modo Demo - Simular pago exitoso
        demo_mode = True  # Cambiar a False cuando tengas Stripe configurado
        
        if demo_mode:
            # Simular Payment Intent
            fake_intent_id = f"pi_demo_{current_user.id}_{datetime.utcnow().timestamp()}"
            
            # Guardar en la base de datos
            payment = Payment(
                user_id=current_user.id,
                stripe_payment_intent_id=fake_intent_id,
                amount=amount,
                membership_type=membership_type,
                status='succeeded'  # Simular pago exitoso
            )
            db.session.add(payment)
            db.session.commit()
            
            # Crear suscripción automáticamente
            end_date = datetime.utcnow() + timedelta(days=365)
            subscription = Subscription(
                user_id=current_user.id,
                payment_id=payment.id,
                membership_type=membership_type,
                status='active',
                end_date=end_date
            )
            db.session.add(subscription)
            db.session.commit()
            
            return jsonify({
                'client_secret': 'demo_client_secret',
                'payment_id': payment.id,
                'demo_mode': True
            })
        else:
            # Modo real con Stripe
            intent = stripe.PaymentIntent.create(
                amount=amount,
                currency='usd',
                metadata={
                    'user_id': current_user.id,
                    'membership_type': membership_type
                }
            )
            
            # Guardar en la base de datos
            payment = Payment(
                user_id=current_user.id,
                stripe_payment_intent_id=intent.id,
                amount=amount,
                membership_type=membership_type,
                status='pending'
            )
            db.session.add(payment)
            db.session.commit()
            
            return jsonify({
                'client_secret': intent.client_secret,
                'payment_id': payment.id,
                'demo_mode': False
            })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/payment-success')
@login_required
def payment_success():
    """Página de éxito del pago"""
    payment_id = request.args.get('payment_id')
    if payment_id:
        payment = Payment.query.get(payment_id)
        if payment and payment.user_id == current_user.id:
            return render_template('payment_success.html', payment=payment)
    
    flash('Información de pago no encontrada.', 'error')
    return redirect(url_for('membership'))

@app.route('/payment-cancel')
@login_required
def payment_cancel():
    """Página de cancelación del pago"""
    flash('El pago fue cancelado. Puedes intentar nuevamente.', 'warning')
    return redirect(url_for('membership'))

@app.route('/stripe-webhook', methods=['POST'])
def stripe_webhook():
    """Webhook de Stripe para confirmar pagos"""
    payload = request.get_data()
    sig_header = request.headers.get('Stripe-Signature')
    
    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, os.getenv('STRIPE_WEBHOOK_SECRET', 'whsec_test')
        )
    except ValueError:
        return 'Invalid payload', 400
    except stripe.error.SignatureVerificationError:
        return 'Invalid signature', 400
    
    # Manejar el evento
    if event['type'] == 'payment_intent.succeeded':
        payment_intent = event['data']['object']
        handle_successful_payment(payment_intent)
    
    return jsonify({'status': 'success'})

def handle_successful_payment(payment_intent):
    """Manejar pago exitoso"""
    try:
        # Buscar el pago en la base de datos
        payment = Payment.query.filter_by(
            stripe_payment_intent_id=payment_intent['id']
        ).first()
        
        if payment:
            # Actualizar estado del pago
            payment.status = 'succeeded'
            db.session.commit()
            
            # Crear suscripción
            end_date = datetime.utcnow() + timedelta(days=365)  # 1 año
            subscription = Subscription(
                user_id=payment.user_id,
                payment_id=payment.id,
                membership_type=payment.membership_type,
                status='active',
                end_date=end_date
            )
            db.session.add(subscription)
            db.session.commit()
            
            # Enviar notificación y email de confirmación
            NotificationEngine.notify_membership_payment(payment.user, payment, subscription)
            
    except Exception as e:
        print(f"Error handling payment: {e}")

class NotificationEngine:
    """Motor de notificaciones para eventos y movimientos del sistema"""
    
    @staticmethod
    def notify_event_registration(event, user, registration):
        """Notificar a moderador, administrador y expositor del evento sobre un nuevo registro"""
        try:
            # Obtener todos los responsables del evento
            recipients = event.get_notification_recipients()
            
            if not recipients:
                print(f"⚠️ No se encontraron responsables para el evento {event.id}")
                return
            
            # Crear notificaciones y enviar emails a todos los responsables
            for recipient in recipients:
                # Crear notificación en la base de datos
                notification = Notification(
                    user_id=recipient.id,
                    event_id=event.id,
                    notification_type='event_registration',
                    title=f'Nuevo registro al evento: {event.title}',
                    message=f'El usuario {user.first_name} {user.last_name} ({user.email}) se ha registrado al evento "{event.title}". Estado: {registration.registration_status}.'
                )
                db.session.add(notification)
                
                # Enviar email al responsable
                try:
                    # Determinar el rol del destinatario
                    role = "Responsable"
                    if event.moderator_id == recipient.id:
                        role = "Moderador"
                    elif event.administrator_id == recipient.id:
                        role = "Administrador"
                    elif event.speaker_id == recipient.id:
                        role = "Expositor"
                    elif event.created_by == recipient.id:
                        role = "Creador"
                    
                    html_content = f"""
                        <h2>Nuevo Registro al Evento</h2>
                        <p>Hola {recipient.first_name},</p>
                        <p>Como <strong>{role}</strong> del evento, te informamos que se ha registrado un nuevo participante:</p>
                        <ul>
                            <li><strong>Evento:</strong> {event.title}</li>
                            <li><strong>Participante:</strong> {user.first_name} {user.last_name}</li>
                            <li><strong>Email:</strong> {user.email}</li>
                            <li><strong>Estado:</strong> {registration.registration_status}</li>
                            <li><strong>Fecha de registro:</strong> {registration.registration_date.strftime('%d/%m/%Y %H:%M')}</li>
                            <li><strong>Precio pagado:</strong> ${registration.final_price:.2f} {event.currency}</li>
                        </ul>
                        <p>Puedes gestionar los registros desde el panel de administración.</p>
                        <p>Saludos,<br>Equipo RelaticPanama</p>
                        """
                    msg = Message(
                        subject=f'[RelaticPanama] Nuevo registro: {event.title}',
                        recipients=[recipient.email],
                        html=html_content
                    )
                    mail.send(msg)
                    notification.email_sent = True
                    notification.email_sent_at = datetime.utcnow()
                    # Registrar en EmailLog
                    log_email_sent(
                        recipient_email=recipient.email,
                        subject=f'[RelaticPanama] Nuevo registro: {event.title}',
                        html_content=html_content,
                        email_type='event_registration_notification',
                        related_entity_type='event',
                        related_entity_id=event.id,
                        recipient_id=recipient.id,
                        recipient_name=f"{recipient.first_name} {recipient.last_name}",
                        status='sent'
                    )
                except Exception as e:
                    print(f"Error enviando email de notificación a {recipient.email}: {e}")
                    # Registrar fallo en EmailLog
                    log_email_sent(
                        recipient_email=recipient.email,
                        subject=f'[RelaticPanama] Nuevo registro: {event.title}',
                        html_content='',
                        email_type='event_registration_notification',
                        related_entity_type='event',
                        related_entity_id=event.id,
                        recipient_id=recipient.id,
                        recipient_name=f"{recipient.first_name} {recipient.last_name}",
                        status='failed',
                        error_message=str(e)
                    )
            
            db.session.commit()
            
        except Exception as e:
            print(f"Error en notify_event_registration: {e}")
            db.session.rollback()
    
    @staticmethod
    def notify_event_cancellation(event, user, registration):
        """Notificar a moderador, administrador y expositor sobre una cancelación"""
        try:
            recipients = event.get_notification_recipients()
            
            if not recipients:
                return
            
            for recipient in recipients:
                role = "Responsable"
                if event.moderator_id == recipient.id:
                    role = "Moderador"
                elif event.administrator_id == recipient.id:
                    role = "Administrador"
                elif event.speaker_id == recipient.id:
                    role = "Expositor"
                elif event.created_by == recipient.id:
                    role = "Creador"
                
                notification = Notification(
                    user_id=recipient.id,
                    event_id=event.id,
                    notification_type='event_cancellation',
                    title=f'Cancelación de registro: {event.title}',
                    message=f'El usuario {user.first_name} {user.last_name} ({user.email}) ha cancelado su registro al evento "{event.title}".'
                )
                db.session.add(notification)
                
                try:
                    html_content = f"""
                        <h2>Cancelación de Registro</h2>
                        <p>Hola {recipient.first_name},</p>
                        <p>Como <strong>{role}</strong> del evento, te informamos que un participante ha cancelado su registro:</p>
                        <ul>
                            <li><strong>Evento:</strong> {event.title}</li>
                            <li><strong>Participante:</strong> {user.first_name} {user.last_name}</li>
                            <li><strong>Email:</strong> {user.email}</li>
                            <li><strong>Fecha de cancelación:</strong> {datetime.utcnow().strftime('%d/%m/%Y %H:%M')}</li>
                        </ul>
                        <p>Saludos,<br>Equipo RelaticPanama</p>
                        """
                    msg = Message(
                        subject=f'[RelaticPanama] Cancelación de registro: {event.title}',
                        recipients=[recipient.email],
                        html=html_content
                    )
                    mail.send(msg)
                    notification.email_sent = True
                    notification.email_sent_at = datetime.utcnow()
                    # Registrar en EmailLog
                    log_email_sent(
                        recipient_email=recipient.email,
                        subject=f'[RelaticPanama] Cancelación de registro: {event.title}',
                        html_content=html_content,
                        email_type='event_cancellation_notification',
                        related_entity_type='event',
                        related_entity_id=event.id,
                        recipient_id=recipient.id,
                        recipient_name=f"{recipient.first_name} {recipient.last_name}",
                        status='sent'
                    )
                except Exception as e:
                    print(f"Error enviando email de cancelación a {recipient.email}: {e}")
                    log_email_sent(
                        recipient_email=recipient.email,
                        subject=f'[RelaticPanama] Cancelación de registro: {event.title}',
                        html_content='',
                        email_type='event_cancellation_notification',
                        related_entity_type='event',
                        related_entity_id=event.id,
                        recipient_id=recipient.id,
                        recipient_name=f"{recipient.first_name} {recipient.last_name}",
                        status='failed',
                        error_message=str(e)
                    )
            
            db.session.commit()
            
        except Exception as e:
            print(f"Error en notify_event_cancellation: {e}")
            db.session.rollback()
    
    @staticmethod
    def notify_event_confirmation(event, user, registration):
        """Notificar a moderador, administrador y expositor cuando se confirma un registro"""
        try:
            recipients = event.get_notification_recipients()
            
            if not recipients:
                return
            
            for recipient in recipients:
                role = "Responsable"
                if event.moderator_id == recipient.id:
                    role = "Moderador"
                elif event.administrator_id == recipient.id:
                    role = "Administrador"
                elif event.speaker_id == recipient.id:
                    role = "Expositor"
                elif event.created_by == recipient.id:
                    role = "Creador"
                
                notification = Notification(
                    user_id=recipient.id,
                    event_id=event.id,
                    notification_type='event_confirmation',
                    title=f'Registro confirmado: {event.title}',
                    message=f'El registro de {user.first_name} {user.last_name} al evento "{event.title}" ha sido confirmado.'
                )
                db.session.add(notification)
                
                try:
                    html_content = f"""
                        <h2>Registro Confirmado</h2>
                        <p>Hola {recipient.first_name},</p>
                        <p>Como <strong>{role}</strong> del evento, te informamos que un registro ha sido confirmado:</p>
                        <ul>
                            <li><strong>Evento:</strong> {event.title}</li>
                            <li><strong>Participante:</strong> {user.first_name} {user.last_name}</li>
                            <li><strong>Email:</strong> {user.email}</li>
                            <li><strong>Estado:</strong> Confirmado</li>
                        </ul>
                        <p>Saludos,<br>Equipo RelaticPanama</p>
                        """
                    msg = Message(
                        subject=f'[RelaticPanama] Registro confirmado: {event.title}',
                        recipients=[recipient.email],
                        html=html_content
                    )
                    mail.send(msg)
                    notification.email_sent = True
                    notification.email_sent_at = datetime.utcnow()
                    # Registrar en EmailLog
                    log_email_sent(
                        recipient_email=recipient.email,
                        subject=f'[RelaticPanama] Registro confirmado: {event.title}',
                        html_content=html_content,
                        email_type='event_confirmation_notification',
                        related_entity_type='event',
                        related_entity_id=event.id,
                        recipient_id=recipient.id,
                        recipient_name=f"{recipient.first_name} {recipient.last_name}",
                        status='sent'
                    )
                except Exception as e:
                    print(f"Error enviando email de confirmación a {recipient.email}: {e}")
                    log_email_sent(
                        recipient_email=recipient.email,
                        subject=f'[RelaticPanama] Registro confirmado: {event.title}',
                        html_content='',
                        email_type='event_confirmation_notification',
                        related_entity_type='event',
                        related_entity_id=event.id,
                        recipient_id=recipient.id,
                        recipient_name=f"{recipient.first_name} {recipient.last_name}",
                        status='failed',
                        error_message=str(e)
                    )
            
            db.session.commit()
            
        except Exception as e:
            print(f"Error en notify_event_confirmation: {e}")
            db.session.rollback()
    
    @staticmethod
    def notify_event_update(event, changes=None):
        """Notificar cambios en un evento a todos los registrados"""
        try:
            event_creator = User.query.get(event.created_by) if event.created_by else None
            
            if not event_creator:
                return
            
            # Notificar al creador
            notification = Notification(
                user_id=event_creator.id,
                event_id=event.id,
                notification_type='event_update',
                title=f'Evento actualizado: {event.title}',
                message=f'Se han realizado cambios en el evento "{event.title}".'
            )
            db.session.add(notification)
            
            # Notificar a todos los registrados
            registrations = EventRegistration.query.filter_by(
                event_id=event.id,
                registration_status='confirmed'
            ).all()
            
            for reg in registrations:
                user = User.query.get(reg.user_id)
                if user:
                    user_notification = Notification(
                        user_id=user.id,
                        event_id=event.id,
                        notification_type='event_update',
                        title=f'Actualización del evento: {event.title}',
                        message=f'El evento "{event.title}" al que estás registrado ha sido actualizado. Revisa los detalles en la plataforma.'
                    )
                    db.session.add(user_notification)
                    
                    try:
                        html_content = f"""
                            <h2>Evento Actualizado</h2>
                            <p>Hola {user.first_name},</p>
                            <p>El evento "{event.title}" al que estás registrado ha sido actualizado.</p>
                            <p>Te recomendamos revisar los detalles del evento en la plataforma.</p>
                            <p>Saludos,<br>Equipo RelaticPanama</p>
                            """
                        msg = Message(
                            subject=f'[RelaticPanama] Actualización: {event.title}',
                            recipients=[user.email],
                            html=html_content
                        )
                        mail.send(msg)
                        user_notification.email_sent = True
                        user_notification.email_sent_at = datetime.utcnow()
                        # Registrar en EmailLog
                        log_email_sent(
                            recipient_email=user.email,
                            subject=f'[RelaticPanama] Actualización: {event.title}',
                            html_content=html_content,
                            email_type='event_update',
                            related_entity_type='event',
                            related_entity_id=event.id,
                            recipient_id=user.id,
                            recipient_name=f"{user.first_name} {user.last_name}",
                            status='sent'
                        )
                    except Exception as e:
                        print(f"Error enviando email de actualización a {user.email}: {e}")
                        log_email_sent(
                            recipient_email=user.email,
                            subject=f'[RelaticPanama] Actualización: {event.title}',
                            html_content='',
                            email_type='event_update',
                            related_entity_type='event',
                            related_entity_id=event.id,
                            recipient_id=user.id,
                            recipient_name=f"{user.first_name} {user.last_name}",
                            status='failed',
                            error_message=str(e)
                        )
            
            db.session.commit()
            
        except Exception as e:
            print(f"Error en notify_event_update: {e}")
            db.session.rollback()
    
    @staticmethod
    def notify_membership_payment(user, payment, subscription):
        """Notificar confirmación de pago de membresía"""
        try:
            # Crear notificación
            notification = Notification(
                user_id=user.id,
                notification_type='membership_payment',
                title='Pago de Membresía Confirmado',
                message=f'Tu pago por la membresía {payment.membership_type.title()} ha sido procesado exitosamente. Válida hasta {subscription.end_date.strftime("%d/%m/%Y")}.'
            )
            db.session.add(notification)
            
            # Enviar email
            if EMAIL_TEMPLATES_AVAILABLE and email_service:
                html_content = get_membership_payment_confirmation_email(user, payment, subscription)
                email_service.send_email(
                    subject='Confirmación de Pago - RelaticPanama',
                    recipients=[user.email],
                    html_content=html_content,
                    email_type='membership_payment',
                    related_entity_type='payment',
                    related_entity_id=payment.id,
                    recipient_id=user.id,
                    recipient_name=f"{user.first_name} {user.last_name}"
                )
                notification.email_sent = True
                notification.email_sent_at = datetime.utcnow()
            else:
                # Fallback al método anterior
                send_payment_confirmation_email(user, payment, subscription)
                notification.email_sent = True
                notification.email_sent_at = datetime.utcnow()
            
            db.session.commit()
        except Exception as e:
            print(f"Error en notify_membership_payment: {e}")
            db.session.rollback()
    
    @staticmethod
    def notify_membership_expiring(user, subscription, days_left):
        """Notificar que la membresía está por expirar"""
        try:
            notification = Notification(
                user_id=user.id,
                notification_type='membership_expiring',
                title=f'Membresía Expirará en {days_left} Días',
                message=f'Tu membresía {subscription.membership_type.title()} expirará el {subscription.end_date.strftime("%d/%m/%Y")}. Renueva ahora para continuar disfrutando de todos los beneficios.'
            )
            db.session.add(notification)
            
            if EMAIL_TEMPLATES_AVAILABLE and email_service:
                html_content = get_membership_expiring_email(user, subscription, days_left)
                email_service.send_email(
                    subject=f'Tu Membresía Expirará en {days_left} Días - RelaticPanama',
                    recipients=[user.email],
                    html_content=html_content,
                    email_type='membership_expiring',
                    related_entity_type='subscription',
                    related_entity_id=subscription.id,
                    recipient_id=user.id,
                    recipient_name=f"{user.first_name} {user.last_name}"
                )
                notification.email_sent = True
                notification.email_sent_at = datetime.utcnow()
            
            db.session.commit()
        except Exception as e:
            print(f"Error en notify_membership_expiring: {e}")
            db.session.rollback()
    
    @staticmethod
    def notify_membership_expired(user, subscription):
        """Notificar que la membresía ha expirado"""
        try:
            notification = Notification(
                user_id=user.id,
                notification_type='membership_expired',
                title='Membresía Expirada',
                message=f'Tu membresía {subscription.membership_type.title()} ha expirado. Renueva ahora para reactivar tus beneficios.'
            )
            db.session.add(notification)
            
            if EMAIL_TEMPLATES_AVAILABLE and email_service:
                html_content = get_membership_expired_email(user, subscription)
                email_service.send_email(
                    subject='Tu Membresía Ha Expirado - RelaticPanama',
                    recipients=[user.email],
                    html_content=html_content,
                    email_type='membership_expired',
                    related_entity_type='subscription',
                    related_entity_id=subscription.id,
                    recipient_id=user.id,
                    recipient_name=f"{user.first_name} {user.last_name}"
                )
                notification.email_sent = True
                notification.email_sent_at = datetime.utcnow()
            
            db.session.commit()
        except Exception as e:
            print(f"Error en notify_membership_expired: {e}")
            db.session.rollback()
    
    @staticmethod
    def notify_membership_renewed(user, subscription):
        """Notificar renovación de membresía"""
        try:
            notification = Notification(
                user_id=user.id,
                notification_type='membership_renewed',
                title='Membresía Renovada',
                message=f'Tu membresía {subscription.membership_type.title()} ha sido renovada exitosamente. Válida hasta {subscription.end_date.strftime("%d/%m/%Y")}.'
            )
            db.session.add(notification)
            
            if EMAIL_TEMPLATES_AVAILABLE and email_service:
                html_content = get_membership_renewed_email(user, subscription)
                email_service.send_email(
                    subject='Membresía Renovada - RelaticPanama',
                    recipients=[user.email],
                    html_content=html_content,
                    email_type='membership_renewed',
                    related_entity_type='subscription',
                    related_entity_id=subscription.id,
                    recipient_id=user.id,
                    recipient_name=f"{user.first_name} {user.last_name}"
                )
                notification.email_sent = True
                notification.email_sent_at = datetime.utcnow()
            
            db.session.commit()
        except Exception as e:
            print(f"Error en notify_membership_renewed: {e}")
            db.session.rollback()
    
    @staticmethod
    def notify_appointment_confirmation(appointment, user, advisor):
        """Notificar confirmación de cita"""
        try:
            notification = Notification(
                user_id=user.id,
                notification_type='appointment_confirmation',
                title='Cita Confirmada',
                message=f'Tu cita con {advisor.first_name} {advisor.last_name} ha sido confirmada para el {appointment.appointment_date.strftime("%d/%m/%Y")} a las {appointment.appointment_time}.'
            )
            db.session.add(notification)
            
            if EMAIL_TEMPLATES_AVAILABLE and email_service:
                html_content = get_appointment_confirmation_email(appointment, user, advisor)
                email_service.send_email(
                    subject='Cita Confirmada - RelaticPanama',
                    recipients=[user.email],
                    html_content=html_content,
                    email_type='appointment_confirmation',
                    related_entity_type='appointment',
                    related_entity_id=appointment.id,
                    recipient_id=user.id,
                    recipient_name=f"{user.first_name} {user.last_name}"
                )
                notification.email_sent = True
                notification.email_sent_at = datetime.utcnow()
            
            db.session.commit()
        except Exception as e:
            print(f"Error en notify_appointment_confirmation: {e}")
            db.session.rollback()
    
    @staticmethod
    def notify_appointment_reminder(appointment, user, advisor, hours_before=24):
        """Notificar recordatorio de cita"""
        try:
            notification = Notification(
                user_id=user.id,
                notification_type='appointment_reminder',
                title=f'Recordatorio: Cita en {hours_before} horas',
                message=f'Recuerda que tienes una cita con {advisor.first_name} {advisor.last_name} el {appointment.appointment_date.strftime("%d/%m/%Y")} a las {appointment.appointment_time}.'
            )
            db.session.add(notification)
            
            if EMAIL_TEMPLATES_AVAILABLE and email_service:
                html_content = get_appointment_reminder_email(appointment, user, advisor, hours_before)
                email_service.send_email(
                    subject=f'Recordatorio: Cita en {hours_before} horas - RelaticPanama',
                    recipients=[user.email],
                    html_content=html_content,
                    email_type='appointment_reminder',
                    related_entity_type='appointment',
                    related_entity_id=appointment.id,
                    recipient_id=user.id,
                    recipient_name=f"{user.first_name} {user.last_name}"
                )
                notification.email_sent = True
                notification.email_sent_at = datetime.utcnow()
            
            db.session.commit()
        except Exception as e:
            print(f"Error en notify_appointment_reminder: {e}")
            db.session.rollback()
    
    @staticmethod
    def notify_welcome(user):
        """Notificar bienvenida a nuevo usuario"""
        try:
            notification = Notification(
                user_id=user.id,
                notification_type='welcome',
                title='¡Bienvenido a RelaticPanama!',
                message='Te damos la bienvenida a RelaticPanama. Explora nuestros eventos, recursos y servicios disponibles.'
            )
            db.session.add(notification)
            
            if EMAIL_TEMPLATES_AVAILABLE and email_service:
                html_content = get_welcome_email(user)
                email_service.send_email(
                    subject='Bienvenido a RelaticPanama',
                    recipients=[user.email],
                    html_content=html_content,
                    email_type='welcome',
                    related_entity_type='user',
                    related_entity_id=user.id,
                    recipient_id=user.id,
                    recipient_name=f"{user.first_name} {user.last_name}"
                )
                notification.email_sent = True
                notification.email_sent_at = datetime.utcnow()
            
            db.session.commit()
        except Exception as e:
            print(f"Error en notify_welcome: {e}")
            db.session.rollback()
    
    @staticmethod
    def notify_event_registration_to_user(event, user, registration):
        """Notificar al usuario sobre su registro a evento"""
        try:
            notification = Notification(
                user_id=user.id,
                event_id=event.id,
                notification_type='event_registration_user',
                title=f'Registro Confirmado: {event.title}',
                message=f'Tu registro al evento "{event.title}" ha sido confirmado. Estado: {registration.registration_status}.'
            )
            db.session.add(notification)
            
            if EMAIL_TEMPLATES_AVAILABLE and email_service:
                html_content = get_event_registration_email(event, user, registration)
                email_service.send_email(
                    subject=f'Registro Confirmado: {event.title}',
                    recipients=[user.email],
                    html_content=html_content,
                    email_type='event_registration',
                    related_entity_type='event',
                    related_entity_id=event.id,
                    recipient_id=user.id,
                    recipient_name=f"{user.first_name} {user.last_name}"
                )
                notification.email_sent = True
                notification.email_sent_at = datetime.utcnow()
            
            db.session.commit()
        except Exception as e:
            print(f"Error en notify_event_registration_to_user: {e}")
            db.session.rollback()
    
    @staticmethod
    def notify_event_cancellation_to_user(event, user):
        """Notificar al usuario sobre cancelación de registro"""
        try:
            notification = Notification(
                user_id=user.id,
                event_id=event.id,
                notification_type='event_cancellation_user',
                title=f'Registro Cancelado: {event.title}',
                message=f'Tu registro al evento "{event.title}" ha sido cancelado.'
            )
            db.session.add(notification)
            
            if EMAIL_TEMPLATES_AVAILABLE and email_service:
                html_content = get_event_cancellation_email(event, user)
                email_service.send_email(
                    subject=f'Cancelación de Registro: {event.title}',
                    recipients=[user.email],
                    html_content=html_content,
                    email_type='event_cancellation',
                    related_entity_type='event',
                    related_entity_id=event.id,
                    recipient_id=user.id,
                    recipient_name=f"{user.first_name} {user.last_name}"
                )
                notification.email_sent = True
                notification.email_sent_at = datetime.utcnow()
            
            db.session.commit()
        except Exception as e:
            print(f"Error en notify_event_cancellation_to_user: {e}")
            db.session.rollback()


def log_email_sent(recipient_email, subject, html_content, text_content=None, 
                   email_type=None, related_entity_type=None, related_entity_id=None,
                   recipient_id=None, recipient_name=None, status='sent', error_message=None):
    """Registrar un email enviado en EmailLog"""
    try:
        email_log = EmailLog(
            recipient_id=recipient_id,
            recipient_email=recipient_email,
            recipient_name=recipient_name or recipient_email,
            subject=subject,
            html_content=html_content[:5000] if html_content else None,
            text_content=text_content[:5000] if text_content else None,
            email_type=email_type or 'general',
            related_entity_type=related_entity_type,
            related_entity_id=related_entity_id,
            status=status,
            error_message=error_message[:1000] if error_message else None,
            sent_at=datetime.utcnow() if status == 'sent' else None
        )
        db.session.add(email_log)
        db.session.commit()
    except Exception as e:
        print(f"Error registrando email en log: {e}")
        db.session.rollback()

def send_payment_confirmation_email(user, payment, subscription):
    """Enviar email de confirmación de pago"""
    try:
        html_content = f"""
            <h2>¡Pago Confirmado!</h2>
            <p>Hola {user.first_name},</p>
            <p>Tu pago por la membresía {payment.membership_type.title()} ha sido procesado exitosamente.</p>
            <p><strong>Detalles del pago:</strong></p>
            <ul>
                <li>Membresía: {payment.membership_type.title()}</li>
                <li>Monto: ${payment.amount / 100:.2f}</li>
                <li>Fecha: {payment.created_at.strftime('%d/%m/%Y')}</li>
                <li>Válida hasta: {subscription.end_date.strftime('%d/%m/%Y')}</li>
            </ul>
            <p>Ya puedes acceder a todos los beneficios de tu membresía.</p>
            <p>¡Gracias por ser parte de RelaticPanama!</p>
            """
        msg = Message(
            subject='Confirmación de Pago - RelaticPanama',
            recipients=[user.email],
            html=html_content
        )
        mail.send(msg)
        # Registrar en EmailLog
        log_email_sent(
            recipient_email=user.email,
            subject='Confirmación de Pago - RelaticPanama',
            html_content=html_content,
            email_type='membership_payment',
            related_entity_type='payment',
            related_entity_id=payment.id,
            recipient_id=user.id,
            recipient_name=f"{user.first_name} {user.last_name}",
            status='sent'
        )
    except Exception as e:
        print(f"Error sending email: {e}")
        # Registrar fallo en EmailLog
        log_email_sent(
            recipient_email=user.email,
            subject='Confirmación de Pago - RelaticPanama',
            html_content='',
            email_type='membership_payment',
            related_entity_type='payment',
            related_entity_id=payment.id,
            recipient_id=user.id,
            recipient_name=f"{user.first_name} {user.last_name}",
            status='failed',
            error_message=str(e)
        )

@app.route('/api/user/membership')
@login_required
def api_user_membership():
    """API para obtener información de membresía del usuario"""
    membership = current_user.get_active_membership()
    if membership:
        return jsonify({
            'type': membership.membership_type,
            'start_date': membership.start_date.isoformat(),
            'end_date': membership.end_date.isoformat(),
            'is_active': membership.is_active,
            'payment_status': membership.payment_status
        })
    return jsonify({'error': 'No active membership found'}), 404

# Rutas de administración
def admin_required(f):
    """Decorador para requerir permisos de administrador"""
    from functools import wraps
    @wraps(f)
    @login_required
    def decorated_function(*args, **kwargs):
        if not current_user.is_admin:
            flash('No tienes permisos para acceder a esta página.', 'error')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/admin')
@admin_required
def admin_dashboard():
    """Panel de administración principal"""
    total_users = User.query.count()
    total_memberships = Membership.query.count()
    active_memberships = Membership.query.filter_by(is_active=True).count()
    total_payments = Payment.query.filter_by(status='succeeded').count()
    total_revenue = sum([p.amount for p in Payment.query.filter_by(status='succeeded').all()]) / 100
    
    # Usuarios recientes
    recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
    
    # Membresías recientes
    recent_memberships = Membership.query.order_by(Membership.created_at.desc()).limit(5).all()
    
    return render_template('admin/dashboard.html',
                         total_users=total_users,
                         total_memberships=total_memberships,
                         active_memberships=active_memberships,
                         total_payments=total_payments,
                         total_revenue=total_revenue,
                         recent_users=recent_users,
                         recent_memberships=recent_memberships)

@app.route('/admin/users')
@admin_required
def admin_users():
    """Gestión de usuarios"""
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template('admin/users.html', users=users)


@app.route('/admin/users/<int:user_id>/update', methods=['POST'])
@admin_required
def admin_update_user(user_id):
    """Actualizar atributos básicos del usuario (admin, asesor, estado)."""
    user = User.query.get_or_404(user_id)
    first_name = request.form.get('first_name', '').strip()
    last_name = request.form.get('last_name', '').strip()
    phone = request.form.get('phone', '').strip()

    if first_name:
        user.first_name = first_name
    if last_name:
        user.last_name = last_name
    user.phone = phone or None

    user.is_active = bool(request.form.get('is_active'))
    user.is_admin = bool(request.form.get('is_admin'))
    wants_advisor = bool(request.form.get('is_advisor'))

    if wants_advisor and not user.is_advisor:
        user.is_advisor = True
        if not user.advisor_profile:
            new_profile = Advisor(
                user_id=user.id,
                headline=request.form.get('advisor_headline', '').strip() or 'Asesor RELATIC',
                specializations=request.form.get('advisor_specializations', '').strip(),
                meeting_url=request.form.get('advisor_meeting_url', '').strip(),
            )
            db.session.add(new_profile)
    elif not wants_advisor and user.is_advisor:
        user.is_advisor = False
        if user.advisor_profile:
            db.session.delete(user.advisor_profile)

    db.session.commit()
    flash('Usuario actualizado correctamente.', 'success')
    return redirect(url_for('admin_users'))

@app.route('/admin/memberships')
@admin_required
def admin_memberships():
    """Gestión de membresías"""
    memberships = Membership.query.order_by(Membership.created_at.desc()).all()
    return render_template('admin/memberships.html', memberships=memberships)

# Rutas administrativas para gestión de mensajería
@app.route('/admin/messaging')
@admin_required
def admin_messaging():
    """Lista de todos los emails enviados"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)
    email_type = request.args.get('type', 'all')
    status = request.args.get('status', 'all')
    search = request.args.get('search', '')
    
    # Construir query
    query = EmailLog.query
    
    # Filtros
    if email_type != 'all':
        query = query.filter_by(email_type=email_type)
    
    if status != 'all':
        query = query.filter_by(status=status)
    
    if search:
        query = query.filter(
            db.or_(
                EmailLog.recipient_email.ilike(f'%{search}%'),
                EmailLog.subject.ilike(f'%{search}%'),
                EmailLog.recipient_name.ilike(f'%{search}%')
            )
        )
    
    # Ordenar por fecha más reciente
    query = query.order_by(EmailLog.created_at.desc())
    
    # Paginación
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    emails = pagination.items
    
    # Estadísticas
    total_emails = EmailLog.query.count()
    sent_emails = EmailLog.query.filter_by(status='sent').count()
    failed_emails = EmailLog.query.filter_by(status='failed').count()
    
    # Tipos de email únicos para el filtro
    email_types = db.session.query(EmailLog.email_type).distinct().all()
    email_types = [t[0] for t in email_types if t[0]]
    
    return render_template('admin/messaging.html',
                         emails=emails,
                         pagination=pagination,
                         total_emails=total_emails,
                         sent_emails=sent_emails,
                         failed_emails=failed_emails,
                         email_types=email_types,
                         current_type=email_type,
                         current_status=status,
                         search=search)

@app.route('/admin/messaging/<int:email_id>')
@admin_required
def admin_messaging_detail(email_id):
    """Detalle de un email específico"""
    email_log = EmailLog.query.get_or_404(email_id)
    return render_template('admin/messaging_detail.html', email_log=email_log)

@app.route('/admin/messaging/<int:email_id>/resend', methods=['POST'])
@admin_required
def admin_messaging_resend(email_id):
    """Reenviar un email que falló"""
    email_log = EmailLog.query.get_or_404(email_id)
    
    if email_log.status == 'sent':
        flash('Este email ya fue enviado exitosamente.', 'info')
        return redirect(url_for('admin_messaging_detail', email_id=email_id))
    
    try:
        # Intentar reenviar
        if email_service:
            success = email_service.send_email(
                subject=email_log.subject,
                recipients=[email_log.recipient_email],
                html_content=email_log.html_content or '',
                text_content=email_log.text_content,
                email_type=email_log.email_type,
                related_entity_type=email_log.related_entity_type,
                related_entity_id=email_log.related_entity_id,
                recipient_id=email_log.recipient_id,
                recipient_name=email_log.recipient_name
            )
            
            if success:
                email_log.status = 'sent'
                email_log.sent_at = datetime.utcnow()
                email_log.error_message = None
                db.session.commit()
                flash('Email reenviado exitosamente.', 'success')
            else:
                email_log.status = 'failed'
                email_log.retry_count += 1
                db.session.commit()
                flash('Error al reenviar el email. Verifica la configuración del servidor de correo.', 'error')
        else:
            flash('Servicio de email no disponible.', 'error')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al reenviar: {str(e)}', 'error')
    
    return redirect(url_for('admin_messaging_detail', email_id=email_id))

@app.route('/admin/messaging/<int:email_id>/delete', methods=['POST'])
@admin_required
def admin_messaging_delete(email_id):
    """Eliminar un registro de email"""
    email_log = EmailLog.query.get_or_404(email_id)
    
    try:
        db.session.delete(email_log)
        db.session.commit()
        flash('Registro de email eliminado.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar: {str(e)}', 'error')
    
    return redirect(url_for('admin_messaging'))

@app.route('/api/admin/messaging/stats')
@admin_required
def api_messaging_stats():
    """API para obtener estadísticas de mensajería"""
    total = EmailLog.query.count()
    sent = EmailLog.query.filter_by(status='sent').count()
    failed = EmailLog.query.filter_by(status='failed').count()
    
    # Estadísticas por tipo
    from sqlalchemy import func
    stats_by_type = db.session.query(
        EmailLog.email_type,
        func.count(EmailLog.id).label('count')
    ).group_by(EmailLog.email_type).all()
    
    # Estadísticas por día (últimos 30 días)
    from datetime import timedelta
    thirty_days_ago = datetime.utcnow() - timedelta(days=30)
    stats_by_day = db.session.query(
        func.date(EmailLog.created_at).label('date'),
        func.count(EmailLog.id).label('count')
    ).filter(
        EmailLog.created_at >= thirty_days_ago
    ).group_by(func.date(EmailLog.created_at)).all()
    
    return jsonify({
        'total': total,
        'sent': sent,
        'failed': failed,
        'by_type': {t[0]: t[1] for t in stats_by_type},
        'by_day': [{'date': str(d[0]), 'count': d[1]} for d in stats_by_day]
    })

# Registrar blueprints de eventos
try:
    from event_routes import events_bp, admin_events_bp, events_api_bp
    app.register_blueprint(events_bp)
    app.register_blueprint(admin_events_bp)
    app.register_blueprint(events_api_bp)
except ImportError as e:
    print(f"Warning: No se pudieron registrar los blueprints de eventos: {e}")

# Registrar blueprints de citas/appointments
try:
    from appointment_routes import appointments_bp, admin_appointments_bp, appointments_api_bp
    app.register_blueprint(appointments_bp)
    app.register_blueprint(admin_appointments_bp)
    app.register_blueprint(appointments_api_bp)
except ImportError as e:
    print(f"Warning: No se pudieron registrar los blueprints de citas: {e}")

# Funciones de utilidad
def create_sample_data():
    """Crear datos de ejemplo"""
    # Crear beneficios de ejemplo
    benefits = [
        Benefit(name='Acceso a Revistas', description='Acceso completo a la biblioteca de revistas especializadas', membership_type='basic'),
        Benefit(name='Base de Datos', description='Acceso a bases de datos de investigación', membership_type='basic'),
        Benefit(name='Asesoría de Publicación', description='Sesiones de asesoría para publicaciones académicas', membership_type='premium'),
        Benefit(name='Soporte Prioritario', description='Soporte técnico prioritario', membership_type='premium'),
    ]
    
    for benefit in benefits:
        if not Benefit.query.filter_by(name=benefit.name).first():
            db.session.add(benefit)
    
    db.session.commit()

# Ruta para obtener notificaciones del usuario
@app.route('/api/notifications')
@login_required
def api_notifications():
    """API para obtener notificaciones del usuario"""
    # Obtener filtros de query params
    notification_type = request.args.get('type', 'all')
    status = request.args.get('status', 'all')  # all, read, unread
    limit = int(request.args.get('limit', 50))
    
    # Construir query
    query = Notification.query.filter_by(user_id=current_user.id)
    
    # Filtrar por tipo
    if notification_type != 'all':
        query = query.filter_by(notification_type=notification_type)
    
    # Filtrar por estado
    if status == 'read':
        query = query.filter_by(is_read=True)
    elif status == 'unread':
        query = query.filter_by(is_read=False)
    
    # Obtener conteos
    unread_count = Notification.query.filter_by(
        user_id=current_user.id,
        is_read=False
    ).count()
    
    # Obtener notificaciones
    notifications = query.order_by(Notification.created_at.desc()).limit(limit).all()
    
    return jsonify({
        'unread_count': unread_count,
        'total': len(notifications),
        'notifications': [{
            'id': n.id,
            'title': n.title,
            'message': n.message,
            'type': n.notification_type,
            'is_read': n.is_read,
            'event_id': n.event_id,
            'created_at': n.created_at.isoformat() if n.created_at else None,
            'email_sent': n.email_sent,
            'email_sent_at': n.email_sent_at.isoformat() if n.email_sent_at else None
        } for n in notifications]
    })

@app.route('/api/notifications/<int:notification_id>/read', methods=['POST'])
@login_required
def mark_notification_read(notification_id):
    """Marcar notificación como leída"""
    notification = Notification.query.filter_by(
        id=notification_id,
        user_id=current_user.id
    ).first_or_404()
    notification.mark_as_read()
    return jsonify({'success': True, 'message': 'Notificación marcada como leída'})

@app.route('/api/notifications/read-all', methods=['POST'])
@login_required
def mark_all_notifications_read():
    """Marcar todas las notificaciones como leídas"""
    try:
        Notification.query.filter_by(
            user_id=current_user.id,
            is_read=False
        ).update({'is_read': True})
        db.session.commit()
        return jsonify({'success': True, 'message': 'Todas las notificaciones han sido marcadas como leídas'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/notifications/<int:notification_id>', methods=['DELETE'])
@login_required
def delete_notification(notification_id):
    """Eliminar notificación"""
    notification = Notification.query.filter_by(
        id=notification_id,
        user_id=current_user.id
    ).first_or_404()
    
    try:
        db.session.delete(notification)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Notificación eliminada'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

def ensure_email_log_columns():
    """Asegurar que todas las columnas necesarias existan en la tabla email_log"""
    try:
        from sqlalchemy import inspect, text
        
        # Verificar si la tabla existe
        inspector = inspect(db.engine)
        if 'email_log' not in inspector.get_table_names():
            print("🔧 Tabla email_log no existe. Creándola...")
            # Crear la tabla usando el modelo
            EmailLog.__table__.create(db.engine, checkfirst=True)
            print("✅ Tabla email_log creada exitosamente con todas las columnas")
            return
        
        columns = [col['name'] for col in inspector.get_columns('email_log')]
        print(f"📋 Columnas actuales en email_log: {', '.join(columns)}")
        
        # Definir todas las columnas que debería tener según el modelo EmailLog
        required_columns = {
            'recipient_id': 'INTEGER',
            'recipient_email': 'VARCHAR(120)',
            'recipient_name': 'VARCHAR(200)',
            'subject': 'VARCHAR(500)',
            'html_content': 'TEXT',
            'text_content': 'TEXT',
            'email_type': 'VARCHAR(50)',
            'related_entity_type': 'VARCHAR(50)',
            'related_entity_id': 'INTEGER',
            'status': 'VARCHAR(20)',
            'error_message': 'TEXT',
            'retry_count': 'INTEGER',
            'sent_at': 'DATETIME',
            'created_at': 'DATETIME'
        }
        
        # Agregar columnas faltantes
        added_columns = []
        for col_name, col_type in required_columns.items():
            if col_name not in columns:
                print(f"🔧 Agregando columna '{col_name}' ({col_type}) a la tabla email_log...")
                try:
                    with db.engine.connect() as conn:
                        conn.execute(text(f"ALTER TABLE email_log ADD COLUMN {col_name} {col_type}"))
                        conn.commit()
                    print(f"✅ Columna '{col_name}' agregada correctamente")
                    added_columns.append(col_name)
                except Exception as col_error:
                    print(f"⚠️ Error agregando columna '{col_name}': {col_error}")
        
        if added_columns:
            print(f"✅ Migración completada: {len(added_columns)} columnas agregadas: {', '.join(added_columns)}")
        else:
            print("✅ Todas las columnas necesarias ya existen en email_log")
        
    except Exception as e:
        print(f"⚠️ Error verificando columnas de email_log: {e}")
        import traceback
        traceback.print_exc()
        # No lanzar excepción para no bloquear el inicio de la app

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        ensure_email_log_columns()  # Asegurar columnas antes de crear datos de muestra
        create_sample_data()
    
    app.run(host='0.0.0.0', port=9000, debug=True)
